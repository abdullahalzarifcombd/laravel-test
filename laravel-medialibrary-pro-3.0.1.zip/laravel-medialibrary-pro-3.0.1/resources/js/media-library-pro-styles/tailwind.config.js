module.exports = {
    purge: false,
};
