// default export needed for nextjs dynamic imports
export { default } from './MediaLibraryCollection';

export { default as MediaLibraryCollection } from './MediaLibraryCollection';
