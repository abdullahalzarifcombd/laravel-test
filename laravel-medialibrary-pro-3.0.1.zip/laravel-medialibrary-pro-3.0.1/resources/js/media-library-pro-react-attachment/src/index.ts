// default export needed for nextjs dynamic imports
export { default } from './MediaLibraryAttachment';

export { default as MediaLibraryAttachment } from './MediaLibraryAttachment';
